# myImageFilterX.py


def myImageFilterX(img0, h):

    return img1
